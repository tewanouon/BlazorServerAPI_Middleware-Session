
window.auth = {
  set: (access) => { sessionStorage.setItem('jwt', access); },
  get: () => sessionStorage.getItem('jwt') || '',
  clear: () => { sessionStorage.removeItem('jwt'); }
};
