using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ApiHost.Controllers.Internal;

[ApiController]
[Route("api/internal/products")]
public class ProductsController : ControllerBase
{
    [HttpGet]
    [Authorize]
    public IActionResult Get() => Ok(new[]{
        new { Id=1, Name="Forklift Battery", Price=12345 },
        new { Id=2, Name="Hydraulic Pump", Price=98765 }
    });

    [HttpPost("approve")]
    [Authorize(Policy = "CanApprove")]
    public IActionResult Approve([FromBody] ApproveDto dto)
        => Ok(new { ok=true, approved=dto.ProductId, at=DateTimeOffset.UtcNow });
}
public record ApproveDto(int ProductId);
