using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace ApiHost.Controllers;

[ApiController]
[Route("auth")]
public class AuthController : ControllerBase
{
    private readonly SymmetricSecurityKey _signingKey;
    public AuthController(SymmetricSecurityKey signingKey) => _signingKey = signingKey;

    [HttpPost("token")]
    public IActionResult Token([FromBody] LoginDto dto)
    {
        var role = dto.Username switch
        {
            "admin" => ("admin","manager"),
            "manager" => ("manager","manager"),
            "user" => ("user","staff"),
            _ => default((string,string))
        };
        if (role == default || (dto.Username == "user" ? dto.Password != "password" : dto.Password != "P@ssw0rd!"))
            return Unauthorized(new { message = "Invalid username or password" });

        var (access, expires) = CreateAccessToken(dto.Username, role.Item1, role.Item2);
        return Ok(new { access_token = access, expires_at = expires, token_type = "Bearer" });
    }

    private (string token, DateTimeOffset expires) CreateAccessToken(string username, string role, string approval)
    {
        var claims = new List<Claim>
        {
            new Claim(ClaimTypes.Name, username),
            new Claim(ClaimTypes.Role, role),
            new Claim("approval_level", approval),
            new Claim("scope", "api.read")
        };

        var expires = DateTimeOffset.UtcNow.AddMinutes(20);
        var token = new JwtSecurityToken(
            claims: claims,
            expires: expires.UtcDateTime,
            signingCredentials: new SigningCredentials(_signingKey, SecurityAlgorithms.HmacSha256));
        return (new JwtSecurityTokenHandler().WriteToken(token), expires);
    }
}

public record LoginDto(string Username, string Password);
