## Version 6

BlazorTwoProjects_v6 (API + UI)

Changes in v6:
- Removed Jwt section from ApiHost/appsettings.json
- API uses a random 64-char key generated at startup (in-memory only; rotate on restart)
- No refresh token; access tokens expire in 20 min
- UI stores token in sessionStorage
- API base URL via environment variable API_BASE_URL
- CORS locked to exact origins via CORS_ORIGINS (comma-separated)

Run:
- API
  Windows:  set CORS_ORIGINS=https://localhost:5201
  Linux/Mac: export CORS_ORIGINS=https://localhost:5201
  dotnet run --project ApiHost/ApiHost.csproj

- UI
  Windows:  set API_BASE_URL=https://localhost:5101
  Linux/Mac: export API_BASE_URL=https://localhost:5101
  dotnet run --project BlazorUi/BlazorUi.csproj
